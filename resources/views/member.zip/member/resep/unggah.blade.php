@extends('member.layouts.main')
@push('css')
<link rel="stylesheet" href="style.css">
@endpush
@section('content')
<div class="container bg-white shadow">
    <div class="row mx-5 my-5">
        <div class="col-5">
            <p class="fs-3">Unggah Resep Dokter</p>
            <p>Apotek Jihan Farma Menerima resep Dokter</p>
        </div>
        <div class="d-flex justify-content-end col-6 mt-4 fs-5"><i class="bi bi-house-door-fill"></i>
            <p>&nbsp;/&nbsp;Unggah resep Dokter</p>
        </div>

    </div>

</div>
<div class="container bg-white shadow my-5">
    <div class="row mx-5 my-5">
        <div class="col-10">
            <p class="fs-3">Unggah Resep Dokter</p>
            <p>Hai bill, Kamu bisa memesan</p>
        </div>
        <div class="row g-10 align-items-center">
            <div class="col-auto">
                <label for="inputPassword6" class="col-form-label fs-5">Gambar Resep</label>
            </div>
            <div class="col-10">
                <input type="file" id="inputPassword6" class="form-control" aria-describedby="passwordHelpInline">
            </div>

        </div>
        <div class="d-grid gap-2">
            <button class="btn btn-primary mt-4 rounded" type="button">Upload</button>
        </div>
    </div>

    @endsection