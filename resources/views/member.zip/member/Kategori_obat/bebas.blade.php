@extends('member.layouts.main')
@push('css')
<link rel="stylesheet" href="style.css">
@endpush
@section('content')
<div class="container bg-white shadow">
    <div class="row mx-5 my-5">
        <div class="col-5">
            <p class="fs-3">Kategori obat</p>
            <p>Daftar obat Kategori Obat Bebas</p>
        </div>
        <div class="d-flex justify-content-end col-6 mt-4 fs-5"><i class="bi bi-house-door-fill"></i>
            <p>&nbsp;/&nbsp;Kategori obat bebas</p>
        </div>

    </div>
    <div class="row mx-5 my-5">
        <div class="col mb-5">
            <div class="card" style="width: 18rem;">
                <img src="Ganja.jpg" class="card-img-top" alt="Ganja.jpg">
                <div class="card-body">
                    <h5 class="card-title fs-5">Ganja</h5>
                    <p class="card-text fs-6 fw-bold text-dark">Rp. 100.000</p>
                    <button type="button" class="btn btn-primary btn-block"><i class="bi bi-basket fs-6">Tambah</i></button>
                </div>
            </div>
        </div>
        <div class="col mb-5">
            <div class="card" style="width: 18rem;">
                <img src="Ganja.jpg" class="card-img-top" alt="Ganja.jpg">
                <div class="card-body">
                    <h5 class="card-title fs-5">Ganja</h5>
                    <p class="card-text fs-6 fw-bold text-dark">Rp. 100.000</p>
                    <button type="button" class="btn btn-primary btn-block"><i class="bi bi-basket fs-6">Tambah</i></button>
                </div>
            </div>
        </div>
        <div class="col mb-5">
            <div class="card" style="width: 18rem;">
                <img src="Ganja.jpg" class="card-img-top" alt="Ganja.jpg">
                <div class="card-body">
                    <h5 class="card-title fs-5">Ganja</h5>
                    <p class="card-text fs-6 fw-bold text-dark">Rp. 100.000</p>
                    <button type="button" class="btn btn-primary btn-block"><i class="bi bi-basket fs-6">Tambah</i></button>
                </div>
            </div>
        </div>
        <div class="col mb-5">
            <div class="card" style="width: 18rem;">
                <img src="Ganja.jpg" class="card-img-top" alt="Ganja.jpg">
                <div class="card-body">
                    <h5 class="card-title fs-5">Ganja</h5>
                    <p class="card-text fs-6 fw-bold text-dark">Rp. 100.000</p>
                    <button type="button" class="btn btn-primary btn-block"><i class="bi bi-basket fs-6">Tambah</i></button>
                </div>
            </div>
        </div>
        <div class="col mb-5">
            <div class="card" style="width: 18rem;">
                <img src="Ganja.jpg" class="card-img-top" alt="Ganja.jpg">
                <div class="card-body">
                    <h5 class="card-title fs-5">Ganja</h5>
                    <p class="card-text fs-6 fw-bold text-dark">Rp. 100.000</p>
                    <button type="button" class="btn btn-primary btn-block"><i class="bi bi-basket fs-6">Tambah</i></button>
                </div>
            </div>
        </div>
        <div class="col mb-5">
            <div class="card" style="width: 18rem;">
                <img src="Ganja.jpg" class="card-img-top" alt="Ganja.jpg">
                <div class="card-body">
                    <h5 class="card-title fs-5">Ganja</h5>
                    <p class="card-text fs-6 fw-bold text-dark">Rp. 100.000</p>
                    <button type="button" class="btn btn-primary btn-block"><i class="bi bi-basket fs-6">Tambah</i></button>
                </div>
            </div>
        </div>

    </div>
    <nav aria-label="Page navigation example">
        <ul class="pagination d-flex justify-content-end me-5 mb-5">
            <li class="page-item">
                <a class="page-link" href="#" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
            <li class="page-item"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item">
                <a class="page-link" href="#" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        </ul>
    </nav>
</div>

@endsection